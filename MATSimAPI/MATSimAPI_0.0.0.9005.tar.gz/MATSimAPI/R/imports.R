#' @importFrom dplyr select mutate all_of filter
NULL

#' @export
#' @importFrom apollo apollo_attach
apollo::apollo_attach

#' @export
#' @importFrom apollo apollo_op
apollo::apollo_op

#' @export
#' @importFrom apollo apollo_detach
apollo::apollo_detach

#' @export
#' @importFrom apollo apollo_combineModels
apollo::apollo_combineModels

#' @export
#' @importFrom apollo apollo_avgInterDraws
apollo::apollo_avgInterDraws

#' @export
#' @importFrom apollo apollo_prepareProb
apollo::apollo_prepareProb

